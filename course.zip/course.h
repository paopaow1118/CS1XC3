/**
 * @file course.h
 * @author Alen Wang (wangk176@pascal.cas.mcmaster.ca)
 * @brief Header code for the course library and its functions
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>

/**
 * @brief Defines the struct course, includes course name, course code, students, the total number of students
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


