/**
 * @file student.h
 * @author Alen Wang (wangk176@pascal.cas.mcmaster.ca)
 * @brief Header code for the student library and its functions
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Defines the struct course, includes course name, course code, students, the total number of students
 * 
 */

typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
